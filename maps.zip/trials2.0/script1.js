// Initialize the map and set the view
const map = L.map('map').setView([19.076, 72.8777], 11);

// Add OpenStreetMap tiles
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19,
  attribution: '© OpenStreetMap'
}).addTo(map);

// Add markers for all drives
const locations = [
  { name: "Andheri Drive", coords: [19.1195, 72.8467] },
  { name: "Dadar Drive", coords: [19.0144, 72.8479] },
  { name: "Juhu Beach Cleanup", coords: [19.1076, 72.8266] },
  { name: "Marine Drive Cleanup", coords: [18.9454, 72.8231] }
];

locations.forEach(loc => {
  L.marker(loc.coords).addTo(map).bindPopup(`<b>${loc.name}</b>`).openPopup();
});

// Handle button clicks to move the map to the specific location
document.querySelectorAll('.location-btn').forEach((btn, index) => {
  btn.addEventListener('click', () => {
    const coords = locations[index].coords;
    map.setView(coords, 14);
  });
});