// Add interactivity to the navigation links or buttons
document.addEventListener("DOMContentLoaded", () => {
    const ctaButton = document.querySelector(".cta-btn");
  
    ctaButton.addEventListener("click", () => {
      alert("Thank you for joining EcoSort!");
    });
  
    const links = document.querySelectorAll(".nav-links a");
    links.forEach(link => {
      link.addEventListener("click", () => {
        alert(`Navigating to ${link.textContent}`);
      });
    });
  });
  