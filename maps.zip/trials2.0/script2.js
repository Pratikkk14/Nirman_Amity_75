// Initialize the map
const map = L.map('map').setView([19.076, 72.8777], 12); // Coordinates for Mumbai

// Add OpenStreetMap tile layer
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
}).addTo(map);

// Data for Waste Collection Centres
const centres = [
  {
    name: 'Centre 1: Andheri East',
    location: [19.1197, 72.8673],
    description: 'A prominent collection centre for plastic and electronic waste.',
  },
  {
    name: 'Centre 2: Bandra West',
    location: [19.0544, 72.8406],
    description: 'Accepts paper, metal, and plastic waste for recycling.',
  },
  {
    name: 'Centre 3: Powai',
    location: [19.1181, 72.9055],
    description: 'Specializes in hazardous waste management.',
  },
  {
    name: 'Centre 4: Lower Parel',
    location: [18.9948, 72.8258],
    description: 'Takes garden and food waste for composting.',
  },
  {
    name: 'Centre 5: Dadar',
    location: [19.0183, 72.8421],
    description: 'Handles general recyclables and e-waste.',
  },
];

// Add markers and flashcards dynamically
const flashcardsContainer = document.getElementById('flashcards');

centres.forEach((centre) => {
  // Add markers to the map
  L.marker(centre.location)
    .addTo(map)
    .bindPopup(`<b>${centre.name}</b><br>${centre.description}`);

  // Create flashcards
  const card = document.createElement('div');
  card.className = 'flashcard';
  card.innerHTML = `
    <h3>${centre.name}</h3>
    <p>${centre.description}</p>
    <button onclick="focusOnLocation(${centre.location[0]}, ${centre.location[1]})">
      Show on Map
    </button>
  `;
  flashcardsContainer.appendChild(card);
});

// Function to focus map on a specific location
function focusOnLocation(lat, lng) {
  map.setView([lat, lng], 15); // Zoom into the specified location
}
